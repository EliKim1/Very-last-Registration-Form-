//create the user construction
class User {
    constructor(fname, lname, email, password, age, address, phonenumber, payment, color) {
        this.firstName = fname;
        this.lastName = lname;
        this.email = email;
        this.password = password;
        this.age = age;
        this.address = address;
        this.phoneNumber = phonenumber;
        this.payment = payment;
        this.color = color;

    }
}
function isValid(user){
    //return true if the user is valid
    //return false if the user is not valid
    let valid=true;
    if(user.email.length==0){
        valid=false;
        $("#txtEmail").addClass("input-error");
        console.error("Please, enter a valid email");
    }
    if(user.password.length==0){
        valid=false;
        $("#txtPassword").addClass("input-error");
        console.error("Please, enter a valid password");
    }
    if(user.address.length==0){
        valid=false;
        $("#txtaddress").addClass("input-error");
        console.error("Please, enter a valid address");
    }
    if(user.phoneNumber.length==0){
        valid=false;
        $("#txtphonenumber").addClass("input-error");
        console.error("Please, enter a valid phone number");
    }
    return valid;
}
function validatePass(){
    console.log("Validating password");
    let txtPass=$("#txtPassword1");
    let password = txtPass.val();// this is the element (input)
    if(password.length<6){
        txtPass.css("background-color", "red");
    }
    else{
        txtPass.css("background-color","green");// this jquery in change the css
    }
}

function passConfirmation(){
    let txtPass1=$("#txtPassword1");
    let txtPass2=$("#txtPassword1");
    
    if(txtPass1==txtxPass2){
       console.log("The password is the same");
    }
    else{
        console.log("The password is different");// this jquery in change the css
    }
}


//create the register function
function register(){

    //get the values from the inputs
    let userName=$("#txtFirstName").val();
    let userLname=$("#txtLastName").val();
    let userEmail=$("#txtEmail").val();
    let userPass=$("#txtPassword1").val();
    let userPass2=$("#txtPassword2").val();
    let userage=$("#txtage").val();
    let useraddress=$("#txtaddress").val();
    let userphonenumber=$("#txtphonenumber").val();
    let userPayment=$("#txtpayment").val();
    let usercolor=$("#txtcolor").val();
    // create the obj
    //display the user on the console

    let newUser=new User(userName,userLname,userEmail,userPass,userPass2,userage,useraddress,userphonenumber,userPayment,usercolor);

    //console.log(userName,userLname,userEmail,userPass,userPass2,userage,useraddress,userphonenumber,userPayment,usercolor);
    console.log(newUser);
    if(isValid(newUser)){
        saveUser(newUser); // this is on the storemanager
    }
}
function init(){
   //hode the userForm
    $("#userForm").hide();
     //hook events
    $("#newUser").on("click",function(){
        $("#userForm").slideDown(3000);    
    });

    $("#userForm").show();
    //hook events
    $("#showForm").on("click",function(){
        $("#userForm").slideUp(3000);    
    });
    $("#txtPassword1").keyup(validatePass);
    $("#txtPassword2").keyup(passConfirmation);


 }


window.onload=init;




//jquery vs javascript
//document.getElementById("txtFirstName").value;
//$("#txtFirstName").val();
//document.getElementById("txtLastName").value;StyleSheet.display="none";
//$("#txtLastName").val();
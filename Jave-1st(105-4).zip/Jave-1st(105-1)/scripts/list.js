
function displayUsers(usersArray){
    //travel the array (for)
    //tr+=(tr,th
    //inject tr into htmltable )
    let tr="";
    for(let i=0;i<usersArray.length; i++){
        let user=usersArray[i];
        tr+=`
            <tr class="user">
                <td>${user.firstName}</td>
                <td>${user.lastName}</td>
                <td>${user.email}</td>
                <td>${user.password}</td>
                <td>${user.age}</td>
                <td>${user.address}</td>
                <td>${user.phoneNumber}</td>
                <td>${user.color}</td>
                <td><button class="btn btn-danger" > Delete </button></td>
            </tr>
        `;
        console.log(tr); 
    }
    $("#user-table").append(tr);
}

function init(){
    console.log("Listing users");
    let users=readUsers();// from the StoreManager
    displayUsers(users)
}
window.onload=init;
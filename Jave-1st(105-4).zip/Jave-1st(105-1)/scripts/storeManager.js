const KEY="users";
function saveUser(userObj){
    let oldData=readUsers();
    oldData.push(userObj);// add the new user
    let value = JSON.stringify(oldData);
    localStorage.setItem(KEY,value);
}
function readUsers(){
    let data=localStorage.getItem(KEY);
    console.log(data);// <-JSON
    if(!data){//is not data?
        return[];//creating the array from

    }else{
        //we have data
        let list = JSON.parse(data);// parsing the JSON string data into an object
        return list; //return array of objects
    }
}